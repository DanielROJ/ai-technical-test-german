## ai-technical-test-german
